'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AppShell }   from '@/components/layout/AppShell'
import { BackHeader } from '@/components/layout/BackHeader'
import { Card }       from '@/components/ui/Card'
import { Btn }        from '@/components/ui/Btn'
import { WaveBar }    from '@/components/ui/WaveBar'
import { BRAND }      from '@/lib/constants'

const TEMPLATES = [
  ['גשם', 'שמש', 'קשת'],
  ['כלב', 'חתול', 'חבר'],
  ['גיטרה', 'ריקוד', 'שמחה'],
]
const LABELS = ['מילה ראשונה 🌟', 'מילה שנייה 🎸', 'מילה שלישית 🌈']
const HINTS  = ['גשם...', 'שמחה...', 'כוכב...']

const buildSong = (w: string[]) => [
  `יש לנו ${w[0]} יפה ומיוחד, 🌟`,
  `עם ${w[1]} הכל הופך לשמחה, 🎉`,
  `ביחד נשיר על ${w[2]} שלנו, 🎶`,
  `הביט של הגן — זה אנחנו! 💖`,
]

export default function MagicSongPage() {
  const [words,   setWords]   = useState(['', '', ''])
  const [loading, setLoading] = useState(false)
  const [song,    setSong]    = useState<string[] | null>(null)
  const [saved,   setSaved]   = useState(false)

  const allFilled = words.every(w => w.trim())

  const setWord = (i: number, val: string) => {
    const n = [...words]; n[i] = val; setWords(n); setSong(null)
  }

  const generate = () => {
    if (!allFilled) return
    setLoading(true); setSong(null); setSaved(false)
    setTimeout(() => { setLoading(false); setSong(buildSong(words)) }, 1800)
  }

  return (
    <AppShell bg="#fffbeb">
      <BackHeader title="שיר הקסם ⭐" bg={BRAND.orange} />
      <div className="p-4 space-y-3">

        {/* Hero */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card style={{ background: `linear-gradient(135deg,${BRAND.yellow}44,${BRAND.orange}22)`, textAlign: 'center', padding: '20px 16px' }}>
            <motion.div animate={{ scale: [1, 1.12, 1] }} transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
              style={{ fontSize: 48, marginBottom: 8 }}>✨🎵✨</motion.div>
            <div className="font-black" style={{ fontSize: 18, color: BRAND.navy }}>יוצרים שיר ביחד!</div>
            <div style={{ color: '#6b7280', fontSize: 14, marginTop: 4 }}>הכניסו 3 מילים ואנחנו ניצור שיר קסום</div>
          </Card>
        </motion.div>

        {/* Inputs */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <div className="font-black mb-3" style={{ fontSize: 15, color: BRAND.navy }}>בחרו את המילים שלכם:</div>
            {words.map((w, i) => (
              <div key={i} style={{ marginBottom: i < 2 ? 12 : 0 }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#9ca3af', marginBottom: 6 }}>
                  {LABELS[i]}
                </label>
                <input value={w} onChange={e => setWord(i, e.target.value)} placeholder={HINTS[i]}
                  style={{
                    width: '100%', padding: '13px 14px', borderRadius: 12,
                    border: `2px solid ${w ? BRAND.orange : '#e5e7eb'}`,
                    fontSize: 17, fontFamily: 'inherit', outline: 'none',
                    background: w ? `${BRAND.yellow}22` : 'white',
                    fontWeight: 700, transition: 'border 0.2s', direction: 'rtl', boxSizing: 'border-box',
                  }}
                />
              </div>
            ))}

            {/* Quick templates */}
            <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid #f3f4f6' }}>
              <div style={{ fontSize: 11, color: '#9ca3af', fontWeight: 700, marginBottom: 8 }}>דוגמאות מהירות:</div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {TEMPLATES.map((t, i) => (
                  <motion.button key={i} whileTap={{ scale: 0.94 }}
                    onClick={() => { setWords(t); setSong(null) }}
                    style={{
                      background: `${[BRAND.cyan, BRAND.green, BRAND.pink][i]}22`,
                      border: `1.5px solid ${[BRAND.cyan, BRAND.green, BRAND.pink][i]}44`,
                      borderRadius: 10, padding: '5px 12px', fontSize: 13,
                      color: [BRAND.cyan, BRAND.green, BRAND.pink][i],
                      fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer',
                    }}>
                    {t.join(' · ')}
                  </motion.button>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Generate */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }}>
          <Btn full onClick={generate} disabled={!allFilled || loading}
            bg={allFilled ? `linear-gradient(135deg,${BRAND.yellow},${BRAND.orange})` : '#e5e7eb'}
            style={{
              padding: '16px', fontSize: 18, borderRadius: 16,
              color: allFilled ? BRAND.navy : '#9ca3af',
              boxShadow: allFilled ? `0 6px 20px ${BRAND.orange}66` : 'none',
              transition: 'all 0.2s',
            }}>
            {loading ? '✨ יוצר את השיר...' : '🎵 צור שיר קסם!'}
          </Btn>
        </motion.div>

        {/* Loading spinner */}
        <AnimatePresence>
          {loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              style={{ textAlign: 'center', padding: '16px 0' }}>
              <motion.div animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                style={{ fontSize: 38, display: 'inline-block' }}>🎵</motion.div>
              <div style={{ color: BRAND.orange, fontWeight: 700, marginTop: 8 }}>השיר בדרך...</div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Song result */}
        <AnimatePresence>
          {song && !loading && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <Card style={{ background: `linear-gradient(135deg,${BRAND.navy},#312e81)` }}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
                  <WaveBar active count={14} height={24} />
                </div>
                <div style={{ textAlign: 'center', color: BRAND.yellow, fontWeight: 800, fontSize: 13, marginBottom: 12 }}>
                  ✨ השיר שלכם ✨
                </div>
                {song.map((line, i) => (
                  <motion.div key={i}
                    initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.14 }}
                    style={{
                      color: 'white', fontWeight: 700, fontSize: 16,
                      padding: '8px 0',
                      borderBottom: i < song.length - 1 ? '1px solid rgba(255,255,255,0.08)' : 'none',
                    }}>
                    {line}
                  </motion.div>
                ))}
                <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                  {([
                    { label: saved ? '✓ נשמר' : '💾 שמור', color: BRAND.pink,  action: () => setSaved(true) },
                    { label: '🎤 הקלט', color: BRAND.cyan,   action: () => {} },
                    { label: '🔊 השמע', color: BRAND.green,  action: () => {} },
                  ] as const).map((btn, i) => (
                    <Btn key={i} bg={btn.color} onClick={btn.action}
                      style={{ flex: 1, textAlign: 'center', padding: '10px 4px', fontSize: 13 }}>
                      {btn.label}
                    </Btn>
                  ))}
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </AppShell>
  )
}
