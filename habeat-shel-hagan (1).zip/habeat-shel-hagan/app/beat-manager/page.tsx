'use client'

import { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AppShell }   from '@/components/layout/AppShell'
import { BackHeader } from '@/components/layout/BackHeader'
import { Card }       from '@/components/ui/Card'
import { Pill }       from '@/components/ui/Pill'
import { Btn }        from '@/components/ui/Btn'
import { WaveBar }    from '@/components/ui/WaveBar'
import { BRAND }      from '@/lib/constants'

const STATIONS = [
  { id: 0, name: 'תחנת הופעה',  emoji: '🎸', color: BRAND.pink,   kids: 6  },
  { id: 1, name: 'רצפת הקצב',   emoji: '🎹', color: BRAND.yellow, kids: 8  },
  { id: 2, name: 'עמדת שירה',   emoji: '🎧', color: BRAND.cyan,   kids: 0  },
  { id: 3, name: 'תחנות טאבלט', emoji: '📱', color: BRAND.purple, kids: 10 },
]
const DEFAULT_SECS = 600
const fmt = (s: number) =>
  `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`

export default function BeatManagerPage() {
  const [secs,    setSecs]   = useState(DEFAULT_SECS)
  const [running, setRun]    = useState(false)
  const [idx,     setIdx]    = useState(0)
  const [log,     setLog]    = useState([
    '10:00 — נפתחה פעילות הביט 🎵',
    '09:55 — כל הילדים בתחנות ✅',
  ])

  useEffect(() => {
    if (!running) return
    const id = setInterval(() => setSecs(s => s > 0 ? s - 1 : 0), 1000)
    return () => clearInterval(id)
  }, [running])

  const switchStation = useCallback(() => {
    const next = (idx + 1) % STATIONS.length
    setIdx(next)
    const t = new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })
    setLog(l => [`${t} — מעבר ל${STATIONS[next].name} ${STATIONS[next].emoji}`, ...l.slice(0, 6)])
  }, [idx])

  const pct    = secs / DEFAULT_SECS
  const R      = 58
  const circ   = 2 * Math.PI * R
  const active = STATIONS[idx]

  return (
    <AppShell bg="#f0f9ff">
      <BackHeader title="מנהל הביט 🎛️" bg={BRAND.cyan} />
      <div className="p-4 space-y-3">

        {/* Timer */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card style={{ background: `linear-gradient(135deg,${BRAND.navy},#312e81)` }} className="text-center py-6">
            <div className="relative inline-flex items-center justify-center" style={{ width: 148, height: 148 }}>
              <svg width="148" height="148" className="absolute" style={{ transform: 'rotate(-90deg)' }}>
                <circle cx="74" cy="74" r={R} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="9" />
                <circle cx="74" cy="74" r={R} fill="none" stroke={BRAND.cyan} strokeWidth="9"
                  strokeLinecap="round" strokeDasharray={circ}
                  strokeDashoffset={circ * (1 - pct)}
                  style={{ transition: 'stroke-dashoffset 0.6s ease' }} />
              </svg>
              <div>
                <div className="font-black text-white" style={{ fontSize: 38, letterSpacing: 3, lineHeight: 1 }}>{fmt(secs)}</div>
                <div className="font-bold" style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, marginTop: 4 }}>זמן נותר</div>
              </div>
            </div>
            <div className="flex justify-center mt-3 mb-5">
              <WaveBar active={running} count={12} color={running ? BRAND.cyan : undefined} height={22} />
            </div>
            <div className="flex justify-center gap-3">
              <Btn bg={running ? '#ef4444' : BRAND.green} onClick={() => setRun(r => !r)}
                style={{ minWidth: 130, fontSize: 16, padding: '12px 24px' }}>
                {running ? '⏸ עצור' : '▶ התחל'}
              </Btn>
              <button onClick={() => { setSecs(DEFAULT_SECS); setRun(false) }}
                style={{ width: 46, height: 46, background: 'rgba(255,255,255,0.14)', border: 'none',
                  borderRadius: 14, color: 'white', fontSize: 20, cursor: 'pointer' }}>↺</button>
            </div>
          </Card>
        </motion.div>

        {/* Active station */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
          <Card style={{ background: `${active.color}1a`, border: `2px solid ${active.color}44` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', marginBottom: 6 }}>תחנה פעילה כעת</div>
            <div className="flex items-center gap-3 mb-3">
              <span style={{ fontSize: 36 }}>{active.emoji}</span>
              <div className="flex-1">
                <div className="font-black" style={{ fontSize: 20, color: active.color }}>{active.name}</div>
                <div style={{ fontSize: 13, color: '#6b7280', fontWeight: 600 }}>{active.kids} ילדים</div>
              </div>
              <Pill color={active.color}>פעילה ✓</Pill>
            </div>
            <Btn bg={active.color} full onClick={switchStation} style={{ fontSize: 16, padding: '13px' }}>
              🔄 החלף תחנה
            </Btn>
          </Card>
        </motion.div>

        {/* Station grid */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
          <div className="grid grid-cols-2 gap-3">
            {STATIONS.map((s, i) => (
              <motion.div key={s.id} whileTap={{ scale: 0.95 }} onClick={() => {
                setIdx(i)
                const t = new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })
                setLog(l => [`${t} — מעבר ל${s.name} ${s.emoji}`, ...l.slice(0, 6)])
              }}>
                <Card style={{
                  padding: 13, textAlign: 'center', cursor: 'pointer',
                  border: `2px solid ${i === idx ? s.color : 'transparent'}`,
                  background: i === idx ? `${s.color}1a` : 'white',
                  transition: 'all 0.2s',
                }}>
                  <div style={{ fontSize: 26, marginBottom: 6 }}>{s.emoji}</div>
                  <div className="font-bold leading-snug" style={{ fontSize: 12, color: BRAND.navy }}>{s.name}</div>
                  <div style={{ marginTop: 8 }}>
                    <Pill color={i === idx ? s.color : '#9ca3af'}>{i === idx ? 'פעילה ✓' : 'ממתינה'}</Pill>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Activity log */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.24 }}>
          <Card>
            <div className="font-black mb-3" style={{ fontSize: 15, color: BRAND.navy }}>יומן פעילות 📋</div>
            <AnimatePresence initial={false}>
              {log.map((entry, i) => (
                <motion.div key={entry + i}
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="py-2.5 border-b border-gray-50 last:border-0"
                  style={{ fontSize: 13, color: '#374151', fontWeight: 500, overflow: 'hidden' }}>
                  {entry}
                </motion.div>
              ))}
            </AnimatePresence>
          </Card>
        </motion.div>

      </div>
    </AppShell>
  )
}
