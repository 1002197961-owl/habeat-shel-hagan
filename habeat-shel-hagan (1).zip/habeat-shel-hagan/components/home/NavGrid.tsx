'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { NAV_SCREENS } from '@/lib/constants'

export function NavGrid() {
  return (
    <nav
      aria-label="ניווט ראשי"
      className="grid grid-cols-2 gap-4 px-5 pb-10"
    >
      {NAV_SCREENS.map((item, i) => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            delay:    0.3 + i * 0.07,
            duration: 0.38,
            ease:     [0.22, 1, 0.36, 1],
          }}
          whileTap={{ scale: 0.95 }}
          whileHover={{ scale: 1.04, y: -3 }}
        >
          <Link href={item.href} className="block no-underline">
            <div
              className="nav-card"
              style={{ background: item.gradient, padding: '22px 16px 20px' }}
            >
              <div style={{ fontSize: 42, marginBottom: 10, lineHeight: 1 }}>
                {item.emoji}
              </div>
              <div
                className="text-white font-extrabold leading-snug text-shadow-sm"
                style={{ fontSize: 14 }}
              >
                {item.label}
              </div>
            </div>
          </Link>
        </motion.div>
      ))}
    </nav>
  )
}
