'use client'

import { motion } from 'framer-motion'
import { WaveBar } from '@/components/ui/WaveBar'

const FLOATERS = [
  { note: '🎵', size: 18, top: 24, left: '7%',  dur: 3.0, delay: 0.0 },
  { note: '🎶', size: 14, top: 56, left: '80%', dur: 4.0, delay: 0.4 },
  { note: '✨', size: 22, top: 14, left: '86%', dur: 3.5, delay: 0.8 },
  { note: '🌟', size: 16, top: 64, left: '5%',  dur: 4.5, delay: 0.3 },
  { note: '🎵', size: 20, top: 36, left: '70%', dur: 3.2, delay: 0.6 },
  { note: '🎶', size: 15, top: 80, left: '52%', dur: 3.8, delay: 1.0 },
]

export function LogoHero() {
  return (
    <motion.section
      className="relative text-center overflow-hidden"
      style={{ paddingTop: 56, paddingBottom: 36, paddingInline: 24 }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Floating music notes */}
      {FLOATERS.map((f, i) => (
        <motion.span
          key={i}
          className="absolute pointer-events-none select-none"
          style={{ fontSize: f.size, top: f.top, left: f.left, opacity: 0.55 }}
          animate={{ y: [0, -12, 0] }}
          transition={{
            duration: f.dur,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: f.delay,
          }}
        >
          {f.note}
        </motion.span>
      ))}

      {/* Glass logo card */}
      <motion.div
        className="card-glass inline-block"
        style={{ paddingInline: 52, paddingBlock: 32, marginBottom: 22 }}
        initial={{ scale: 0.88, opacity: 0 }}
        animate={{ scale: 1,    opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.34, 1.56, 0.64, 1] }}
      >
        {/* Logo text */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.4 }}
        >
          <span
            className="block font-black leading-none text-shadow-glow-pink"
            style={{ color: '#FF4DA6', fontSize: 62 }}
          >
            הביט
          </span>
          <span
            className="block font-extrabold text-white"
            style={{ fontSize: 36, marginTop: 4 }}
          >
            של הגן
          </span>
        </motion.div>

        {/* Animated waveform */}
        <motion.div
          className="flex justify-center"
          style={{ marginTop: 18 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <WaveBar active count={16} height={26} />
        </motion.div>
      </motion.div>

      {/* Tagline */}
      <motion.p
        className="text-white/80 font-bold m-0"
        style={{ fontSize: 16, letterSpacing: '0.22em' }}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.45, duration: 0.4 }}
      >
        קצב. יצירה. דמיון.
      </motion.p>
    </motion.section>
  )
}
