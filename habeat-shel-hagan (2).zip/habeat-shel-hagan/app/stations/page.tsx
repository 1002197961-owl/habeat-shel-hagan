'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { AppShell }   from '@/components/layout/AppShell'
import { BackHeader } from '@/components/layout/BackHeader'
import { Card }       from '@/components/ui/Card'
import { Pill }       from '@/components/ui/Pill'
import { Toggle }     from '@/components/ui/Toggle'
import { BRAND }      from '@/lib/constants'
import { PILOT_STATIONS } from '@/lib/mockData'

export default function StationsPage() {
  const [stations, setStations] = useState(PILOT_STATIONS)
  const [expanded, setExpanded] = useState<number | null>(null)

  const toggle = (id: number) =>
    setStations(ss => ss.map(s => s.id === id ? { ...s, active: !s.active } : s))

  const activeCount = stations.filter(s => s.active).length

  return (
    <AppShell bg="#fff0f8">
      <BackHeader title="תחנות כלי נגינה 🎸" bg={BRAND.pink} />
      <div className="p-4 space-y-3">

        {/* Summary banner */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card style={{ background: `${BRAND.pink}18`, border: `2px solid ${BRAND.pink}33` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 32 }}>🏆</span>
              <div style={{ flex: 1 }}>
                <div className="font-black" style={{ fontSize: 15, color: BRAND.navy }}>ציוד פיילוט — 4 תחנות</div>
                <div style={{ fontSize: 13, color: '#6b7280' }}>{activeCount} תחנות פעילות כרגע</div>
              </div>
              <Pill color={BRAND.green}>{activeCount}/4 פעילות</Pill>
            </div>
          </Card>
        </motion.div>

        {/* Station cards */}
        {stations.map((s, i) => (
          <motion.div key={s.id}
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 + i * 0.08 }}>
            <Card style={{ border: `2px solid ${expanded === s.id ? s.color : 'transparent'}`, transition: 'border 0.2s' }}>

              <div style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}
                onClick={() => setExpanded(expanded === s.id ? null : s.id)}>

                {/* Icon */}
                <div style={{
                  width: 60, height: 60, borderRadius: 18, flexShrink: 0,
                  background: `${s.color}22`, border: `2px solid ${s.color}44`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30,
                }}>{s.emoji}</div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="font-black" style={{ fontSize: 16, color: BRAND.navy }}>{s.name}</div>
                  <div style={{ fontSize: 13, color: '#6b7280', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {s.subtitle}
                  </div>
                  <div style={{ marginTop: 6 }}>
                    <Pill color={s.active ? BRAND.green : '#9ca3af'}>
                      {s.active ? '✓ פעילה' : '⏸ כבויה'}
                    </Pill>
                  </div>
                </div>

                {/* Toggle — stop propagation so tap doesn't expand */}
                <div onClick={e => { e.stopPropagation(); toggle(s.id) }}>
                  <Toggle on={s.active} onChange={() => toggle(s.id)} color={s.color} />
                </div>
              </div>

              {/* Expanded stats */}
              <AnimatePresence>
                {expanded === s.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }} style={{ overflow: 'hidden' }}>
                    <div style={{
                      marginTop: 14, paddingTop: 14, borderTop: '1px solid #f3f4f6',
                      display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8,
                    }}>
                      {([
                        ['ילדים כעת',  s.kidsNow],
                        ['שירים היום', s.songsToday],
                        ['זמן פעיל',   `${s.minutesActive}ד`],
                      ] as [string, string | number][]).map(([label, value]) => (
                        <div key={label} style={{ textAlign: 'center' }}>
                          <div className="font-black" style={{ fontSize: 22, color: s.color, lineHeight: 1 }}>{value}</div>
                          <div style={{ fontSize: 11, color: '#9ca3af', fontWeight: 700, marginTop: 3 }}>{label}</div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </motion.div>
        ))}

      </div>
    </AppShell>
  )
}
